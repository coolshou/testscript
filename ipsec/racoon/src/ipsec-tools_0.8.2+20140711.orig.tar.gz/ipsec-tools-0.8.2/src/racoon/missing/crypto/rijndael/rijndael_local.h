/*	$NetBSD: rijndael_local.h,v 1.4 2006/09/09 16:22:36 manu Exp $	*/

/*	$KAME: rijndael_local.h,v 1.1.1.1 2001/08/08 09:56:27 sakane Exp $	*/

/* the file should not be used from outside */
typedef u_int8_t		BYTE;
typedef u_int8_t		word8;	
typedef u_int16_t		word16;	
typedef u_int32_t		word32;

#define MAXKC		RIJNDAEL_MAXKC
#define MAXROUNDS	RIJNDAEL_MAXROUNDS
